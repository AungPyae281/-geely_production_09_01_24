<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/test_drive.php';	

date_default_timezone_set('Asia/Rangoon'); 
session_start();

$database = new Database();
$db = $database->getConnection();
 
$test_drive = new TestDrive($db);
$data = json_decode(file_get_contents("php://input"));
	
$test_drive->customer_id = $data->customer_id;	
$test_drive->sales_executive_id = $_SESSION['staff_id'];
$test_drive->date = $data->date;
$test_drive->time = date("H:i", strtotime($data->time));
$test_drive->model = $data->model;
$test_drive->plate_no = $data->plate_no;
$test_drive->booking_entry_by = $_SESSION['user'];
$test_drive->booking_entry_date_time = date("Y-m-d H:i:s");	
 
if($test_drive->create()){	

	if($data->license_front){
	    if (strpos($data->license_front, 'https://clusclient.com/geely') !== false) {

	    }else{
	        if (!is_dir('./upload/' . $test_drive->id)) {
	            mkdir('./upload/' . $test_drive->id, 0777, true);
	        }
	        if(file_exists("./upload/" . $test_drive->id . "/front.png")){
		        unlink("./upload/" . $test_drive->id . "/front.png");
		    }
	        $img = $data->license_front;
	        $img_data = base64_decode(explode(',', $img)[1]);
	        $file = "./upload/" . $test_drive->id . "/front.png" ;//uniqid()
	        $success = file_put_contents($file, $img_data);
	    }
	}

	if($data->license_back){
	    if (strpos($data->license_back, 'https://clusclient.com/geely') !== false) {

	    }else{
	        if (!is_dir('./upload/' . $test_drive->id)) {
	            mkdir('./upload/' . $test_drive->id, 0777, true);
	        }
	        if(file_exists("./upload/" . $test_drive->id . "/back.png")){
		        unlink("./upload/" . $test_drive->id . "/back.png");
		    }
	        $img = $data->license_back;
	        $img_data = base64_decode(explode(',', $img)[1]);
	        $file = "./upload/" . $test_drive->id . "/back.png" ;//uniqid()
	        $success = file_put_contents($file, $img_data);
	    }
	}

	if($data->profile){
	    if (strpos($data->profile, 'https://clusclient.com/geely') !== false) {

	    }else{
	        if (!is_dir('./upload/' . $test_drive->id)) {
	            mkdir('./upload/' . $test_drive->id, 0777, true);
	        }
	        if(file_exists("./upload/" . $test_drive->id . "/profile.png")){
		        unlink("./upload/" . $test_drive->id . "/profile.png");
		    }
	        $img = $data->profile;
	        $img_data = base64_decode(explode(',', $img)[1]);
	        $file = "./upload/" . $test_drive->id . "/profile.png" ;//uniqid()
	        $success = file_put_contents($file, $img_data);
	    }
	}

	$msg_arr = array(
		"message" => "created",
		"id" => $test_drive->id
	);
}else{
	$msg_arr = array(
		"message" => "error"
	);
}
echo json_encode($msg_arr);
?>