<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/test_drive.php';

date_default_timezone_set('Asia/Rangoon'); 
 
$database = new Database();
$db = $database->getConnection();

$test_drive = new TestDrive($db);
$data = json_decode(file_get_contents("php://input"));

$test_drive->id = $data->id;
$test_drive->getOneRow();

$photo = array();
$dir = "./upload_log/" . $data->id ;

if(file_exists($dir)){
	$dh  = opendir($dir);
	while (false !== ($filename = readdir($dh))) {
		$files[] = $filename;
	}

	foreach($files as $file) {
		if ($file != "." && $file != ".." && $file != "thumbnail") {
			$filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file);
			array_push($photo, $file);
		}
	}
}

$front = $back = $profile = $signature = false;
$dir1 = "./upload/" . $data->id;

if(file_exists($dir1)){
	$front = file_exists($dir1 . "/front.png");
	$back = file_exists($dir1 . "/back.png");
	$profile = file_exists($dir1 . "/profile.png");
	$signature = file_exists($dir1 . "/signature.png");
}

$tt = strtotime($test_drive->time);
$add_time = date("H:i", strtotime('+30 minutes', $tt));//add 30 Minutes to time;

$license_photos = array();
if($front==true){
	array_push($license_photos, $dir1 . "/front.png");
}
if($back==true){
	array_push($license_photos, $dir1 . "/back.png");
}

$arr = array(
    "id" =>  $test_drive->id,
    "registration_no" => $test_drive->registration_no,
    "name" => $test_drive->name,
    "mobile_no" => $test_drive->mobile_no,	
	"model" => $test_drive->model,
	"plate_no" => $test_drive->plate_no,
	"date" => $test_drive->date,
	"time" => date('h:i A', strtotime($test_drive->time)),	
	"license_no" => $test_drive->license_no,
	"drive_route" => $test_drive->drive_route,
	"feedback" => $test_drive->feedback,
	"sales_executive" => $test_drive->sales_executive,
	"time_out" => (($test_drive->time_out)?date('h:i A', strtotime($test_drive->time_out)):date('h:i A', strtotime($test_drive->time))),
	"time_in" => (($test_drive->time_in)?date('h:i A', strtotime($test_drive->time_in)):date('h:i A', strtotime($add_time))),
	"agree" => $test_drive->agree,
	"exterior" => $test_drive->exterior,
	"interior" => $test_drive->interior,
	"acceleration" => $test_drive->acceleration,
	"braking" => $test_drive->braking,
	"stability" => $test_drive->stability,
	"visibility" => $test_drive->visibility,
	"comfort" => $test_drive->comfort,
	"noice_level" => $test_drive->noice_level,
	"front" => $front,
	"back" => $back,
	"profile" => $profile,
	"signature" => $signature,
	"photo" => $photo,
	"license_photos" => $license_photos
);

echo json_encode($arr);

?>