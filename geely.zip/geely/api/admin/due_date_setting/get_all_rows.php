<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	include_once '../../config/database.php';
	include_once '../../objects/due_date_setting.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$due_date_setting = new DueDateSetting($db);

	$stmt = $due_date_setting->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"process" => $process,
				"due_day" => (int)$due_day,
				"due_hour" => (int)$due_hour
			);
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>