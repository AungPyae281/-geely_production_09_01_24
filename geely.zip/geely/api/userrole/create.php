<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../config/database.php';
	include_once '../objects/user_role.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$user_role = new UserRole($db);
	$data = json_decode(file_get_contents("php://input"));

	$user_role->dashboard = $data->dashboard;
	$user_role->role_name = $data->role_name;
	$user_role->delete();

	foreach($data->processes as $process){
		$user_role->process = $process->process;
		$user_role->create = $process->create;
		$user_role->read = $process->read;
		$user_role->update = $process->update;
		$user_role->delete = $process->delete;
		$user_role->export = $process->export;
		$user_role->print = $process->print;

		if(!$user_role->create()){
			$arr = array(
				"message" => "error"
			);
			echo json_encode($arr);
			die();
		}
	}

	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>