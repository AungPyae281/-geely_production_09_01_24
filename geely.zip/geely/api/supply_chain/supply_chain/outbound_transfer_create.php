<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_stock.php';
	include_once '../../objects/car_outbound_transfer.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$car_stock = new CarStock($db);
	$car_outbound_transfer = new CarOutboundTransfer($db);
	$data = json_decode(file_get_contents("php://input"));

	$car_outbound_transfer->from_to = $data->from;
	$car_outbound_transfer->transfer_date = $data->transfer_date;
	$car_outbound_transfer->estimated_arrival_date = $data->estimated_arrival_date;
	$car_outbound_transfer->transporter_name = $data->transporter_name;
	$car_outbound_transfer->transporter_phone = $data->transporter_phone;
	$car_outbound_transfer->location = $data->location;
	$car_outbound_transfer->entry_by = $_SESSION['user'];
	$car_outbound_transfer->entry_date_time = date("Y-m-d H:i:s");

	foreach ($data->car_lists as $cslist) {
		$car_stock->id = $cslist->car_stock_id;

		if($data->from=="Factory to Shipment"){			
			$car_stock->bl_no = $data->bl_no;
			$car_stock->import_license_no = $data->import_license_no;
			$car_stock->lot_no = $data->lot_no;
		}else{
			$car_stock->bl_no = $cslist->bl_no;
			$car_stock->import_license_no = $cslist->import_license_no;
			$car_stock->lot_no = $cslist->lot_no;
		}

		if($cslist->id_no){
			$car_stock->id_no = $cslist->id_no;
		}else{
			$car_stock->id_no = $car_stock->checkIDNO($cslist->car_stock_id);
		}
		if($cslist->bounded_approval_code){
			$car_stock->bounded_approval_code = $cslist->bounded_approval_code;
		}else{
			$car_stock->bounded_approval_code = $car_stock->checkBAC($cslist->car_stock_id);
		}
		$car_stock->stock_status = $data->from;
		$car_stock->location = $data->location;
		$car_outbound_transfer->car_stock_id = $cslist->car_stock_id;
		
		if($car_stock->updateOutboundTransfer()){
			$car_outbound_transfer->create();
		}else{
			$arr = array(
				"message" => "errorUpdate"
			);
			echo json_encode($arr);
			die();
		}	
	}
	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>