<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_stock_transfer.php';
	include_once '../../objects/car_stock.php';

	session_start();
	date_default_timezone_set("Asia/Rangoon");

	$database = new Database();
	$db = $database->getConnection();

	$car_stock_transfer = new CarStockTransfer($db);
	$car_stock = new CarStock($db);
	$data = json_decode($_POST['objArr']);

	$car_stock_transfer->car_stock_id = $data[0]->car_stock_id;
	$car_stock_transfer->from = $data[0]->from;
	$car_stock_transfer->to = $data[0]->to;
	$car_stock_transfer->transfer_date = $data[0]->transfer_date;
	$car_stock_transfer->transfer_time = $data[0]->transfer_time;
	$car_stock_transfer->arrival_date = $data[0]->arrival_date;
	$car_stock_transfer->arrival_time = $data[0]->arrival_time;
	$car_stock_transfer->transporter = $data[0]->transporter;
	$car_stock_transfer->departure_mileage = $data[0]->departure_mileage;
	$car_stock_transfer->departure_fuel_level = $data[0]->departure_fuel_level;
	$car_stock_transfer->arrival_mileage = $data[0]->arrival_mileage;
	$car_stock_transfer->arrival_fuel_level = $data[0]->arrival_fuel_level;
	$car_stock_transfer->transfer_reason = $data[0]->transfer_reason;
	$car_stock_transfer->driver_id = $data[0]->driver_id;
	$car_stock_transfer->t_name = $data[0]->t_name;
	$car_stock_transfer->t_phone = $data[0]->t_phone;

	$car_stock_transfer->entry_by = $_SESSION['user'];
	$car_stock_transfer->entry_date_time = date("Y-m-d H:i:s");

	$car_stock->id = $data[0]->car_stock_id;
	$car_stock->location = $data[0]->to;

	if($car_stock_transfer->create()){
		if(!empty($_FILES['fileInspectionIn']))
			{
				$ext = pathinfo($_FILES['fileInspectionIn']['name'], PATHINFO_EXTENSION);
				if($ext!=""){
					if (!is_dir('./upload/' . $car_stock_transfer->id)) {
				        mkdir('./upload/' . $car_stock_transfer->id, 0777, true);
				    }

					$newname = "InspectionIn." . $ext;
					$targetPath = './upload/' . $car_stock_transfer->id . '/' . $newname;
					move_uploaded_file($_FILES['fileInspectionIn']['tmp_name'], $targetPath);
					$file_inspection_in = $newname;
				}	
			}

		if(!empty($_FILES['fileInspectionOut']))
			{
				$ext = pathinfo($_FILES['fileInspectionOut']['name'], PATHINFO_EXTENSION);
				if($ext!=""){
					if (!is_dir('./upload/' . $car_stock_transfer->id)) {
				        mkdir('./upload/' . $car_stock_transfer->id, 0777, true);
				    }

					$newname1 = "InspectionOut." . $ext;
					$targetPath = './upload/' . $car_stock_transfer->id . '/' . $newname1;
					move_uploaded_file($_FILES['fileInspectionOut']['tmp_name'], $targetPath);
					$file_inspection_out = $newname1;
				}	
			}

		$car_stock_transfer->id = $car_stock_transfer->id;
		$car_stock_transfer->inspection_in = $file_inspection_in;
		$car_stock_transfer->inspection_out = $file_inspection_out;

		$car_stock_transfer->updateFileName();

		$car_stock->updateLocation();

		$arr = array(
			"message" => "created"
		);
	}else{
		$arr = array(
			"message" => "error"
		);
	}
	echo json_encode($arr);
?>