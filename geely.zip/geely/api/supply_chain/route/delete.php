<?php

// required headers
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/route.php';

    $database = new Database();
    $db = $database->getConnection();

    $route = new Route($db);

    $arr = array();
    $arr["records"] = array();

$data = json_decode(file_get_contents("php://input"));
$route->id = $data->id;

if($route->delete()){
    $arr = array(
        "message" => "deleted"
    );
}else{

    $arr = array(
        "message" => "error"
    );
}
    echo json_encode($arr);
?>