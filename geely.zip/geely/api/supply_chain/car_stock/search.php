<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/car_stock.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $car_stock = new CarStock($db);
    $data = json_decode(file_get_contents("php://input")); 

    $car_stock->df = $data->df;
    $car_stock->dt = $data->dt;
    $car_stock->import_license_no = $data->import_license_no;

    $stmt = $car_stock->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "date" => $date,
                "oc_no" => $oc_no,
                "lot_no" => $lot_no,
                "bl_no" => $bl_no,
                "import_license_no" => $import_license_no,
                "brand" => $brand,
                "model" => $model,
                "model_year" => $model_year,
                "grade" => $grade,
                "engine_power" => $engine_power,
                "interior_color" => $interior_color,
                "exterior_color" => $exterior_color,
                "vin_no" => $vin_no,
                "engine_no" => $engine_no,
                "stock_status" => $stock_status,
                "location" => $location,
                "entry_date_time" => $entry_date_time,
                "period" => $period
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>