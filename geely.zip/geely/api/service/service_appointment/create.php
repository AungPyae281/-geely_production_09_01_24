<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_appointment.php';
	include_once '../../objects/service_appointment_item.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$service_appointment = new ServiceAppointment($db);
	$service_appointment_item = new ServiceAppointmentItem($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service_appointment->service_car_id = $data->service_car_id;
		$service_appointment->service_customer_id = $data->service_customer_id;
		$service_appointment->plate_no = $data->plate_no;
		$service_appointment->appointment_type = $data->appointment_type;
		$service_appointment->appointment_date = $data->appointment_date;
		$service_appointment->appointment_time = $data->appointment_time;
		$service_appointment->contact_phone = $data->contact_phone;	
		$service_appointment->contact_person = $data->contact_person;
		$service_appointment->service_center = $data->service_center;
		$service_appointment->total_waiting_time = $data->total_waiting_time;

		if($service_appointment->isExist()){
			$msg_arr = array(
				"message" => "duplicate",
				"plate_no" => $service_appointment->plate_no
			);
		}else{
			if($service_appointment->create()){
				foreach($data->details as $detail){
					$service_appointment_item->service_appointment_id = $service_appointment->id;
					$service_appointment_item->service_item_id = $detail->service_item_id;
					$service_appointment_item->waiting_time = $detail->waiting_time;
					
					if(!$service_appointment_item->create()){
						$msg_arr = array(
							"message" => "errorDetail"
						);
						echo json_encode($msg_arr);
						die();
					}
				}
			}else{
				$msg_arr = array(
					"message" => "error"
				);
				echo json_encode($msg_arr);
				die();
			}
			$msg_arr = array(
				"message" => "created"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>