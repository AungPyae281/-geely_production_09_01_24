<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_item.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_item = new ServiceItem($db);   

    $stmt = $service_item->getAllServiceItem();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array(); 

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array( 
                $code,
                $name,
                $waiting_time,
                number_format($price),
                $id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>