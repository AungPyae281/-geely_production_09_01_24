<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/bank_account_transfer.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$bank_account_transfer = new BankAccountTransfer($db);
	$data = json_decode(file_get_contents("php://input"));

	$bank_account_transfer->date = (!empty($data->date))?$data->date:"";
	
	$stmt = $bank_account_transfer->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"account_from" => $account_from,
				"account_to" => $account_to,
				"date" => $date,
				"amount_from" => (float)$amount_from,
				"amount_to" => (float)$amount_to, 
				"exchange_rate" => (float)$exchange_rate, 
				"upload_receipt" => $upload_receipt
			);
			array_push($arr["records"], $detail);
		} 
	} 
	echo json_encode($arr);
?>