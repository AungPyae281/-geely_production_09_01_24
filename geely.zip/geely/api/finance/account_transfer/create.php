<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/account_transfer.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $account_transfer = new AccountTransfer($db);
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $account_transfer->upload_receipt = $newname;  

    $account_transfer->gl_code_from = $data[0]->gl_code_from;
    $account_transfer->gl_code_to = $data[0]->gl_code_to;
    $account_transfer->date = $data[0]->date;
    $account_transfer->amount = $data[0]->amount;
    $account_transfer->transfer_by = $data[0]->transfer_by;

    $account_transfer->entry_by = $_SESSION['user'];
    $account_transfer->entry_date_time = date("Y-m-d H:i:s");

    if($account_transfer->create()){
        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>