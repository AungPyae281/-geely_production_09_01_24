<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';

    date_default_timezone_set('Asia/Rangoon');  
    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);

    $arr = array();
    $arr["data"] = array();
    
    if($_SESSION['staff_id']!=""){

        $sales->staff_id = $_SESSION['staff_id'];
        $sales->position = $_SESSION['position'];

        $stmt = $sales->getSalesList();
        $num = $stmt->rowCount();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row); 
                $appt_date_time = "";
                if($appointment_date){
                    $appt_date_time = $appointment_date . ' ' . date('h:i A', strtotime($appointment_time));
                }
                $process = $processing;
                if($processing=="Document Collect" || $processing=="Purchase Permit" || $processing=="Income Tax" || $processing=="RTA Appointment" || $processing=="Plate Number"){
                    $processing = "RTA (" . $processing . ")";
                }

                if($processing=="Fill the Fuel" || $processing=="PDI Check List"){
                    $processing = "Pre-Handover Arrangement (" . $processing . ")";
                }

                $detail = array(    
                    (($processing)?$processing:""),
                    $date . substr($entry_date_time, 10, 6),
                    $oc_no,
                    $name, 
                    (($vin_no)?$vin_no:""), 
                    number_format($selling_price), 
                    $payment_type,
                    (($percent)?ROUND($percent, 2):"0") . "%", 
                    (($payment_due_date_time)?$payment_due_date_time:$dc_due_date_time),
                    $appt_date_time,
                    $oc_no . "|" . (($process!="Deposit Collect" && ROUND($percent, 2)<100)?1:0) . "|" . ((ROUND($percent, 2)>=50)?1:0),
                    $process
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>