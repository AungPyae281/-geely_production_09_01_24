<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;

    $sales->getOneDeliveryNote();

    $colour_ext_int = "";
    if($sales->exterior_color){
        $colour_ext_int = $sales->exterior_color;
    }
    if($sales->exterior_color){
        $colour_ext_int .= (($colour_ext_int!="")?"/":"") . $sales->interior_color;
    }
    $arr = array(
        "delivery_to" => $sales->c_name,
        "phone_no" => $sales->c_mobile_no,
        "address" => $sales->c_address,
        "model" => $sales->model,
        "grade" => $sales->grade,
        "vin_no" => $sales->vin_no,
        "engine" => $sales->engine_no,
        "colour_ext_int" => $colour_ext_int,
        "sales_person" => $sales->sales_person
    );
    echo json_encode($arr);
?>