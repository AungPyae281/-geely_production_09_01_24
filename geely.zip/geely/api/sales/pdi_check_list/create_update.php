<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/pdi_check_list.php';   
    include_once '../../objects/sales.php';  
    
    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $pdi_check_list = new PDICheckList($db);  
    $sales = new Sales($db);  
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['staff_id']!=""){
        $pdi_check_list->oc_no = $data->oc_no;
        $pdi_check_list->entry_by = $_SESSION['user'];
        $pdi_check_list->entry_date_time = date("Y-m-d H:i:s");

        //upload image
        if(COUNT($data->car_sheet_detail)>0){
            foreach ($data->car_sheet_detail as $detail) {
                if (!is_dir('./upload/' . $data->oc_no)) {
                    mkdir('./upload/' . $data->oc_no, 0777, true);
                }
                if(file_exists("./upload/" . $data->oc_no . "/car-sheet-" . $detail->id .".png")){
                    unlink("./upload/" . $data->oc_no . "/car-sheet-" . $detail->id .".png");
                }
                $img = $detail->val;
                $img_data = base64_decode(explode(',', $img)[1]);
                $file = "./upload/" . $data->oc_no . "/car-sheet-" . $detail->id .".png";
                $success = file_put_contents($file, $img_data);

                $chk_val = array_search($detail->id, array_column($data->field_detail, 'id'));
                
                $data->field_detail[$chk_val]->val = $file;
            }
        }
        //upload image

        if(!$pdi_check_list->exist()){
            $pdi_check_list->create();
        }

        foreach ($data->field_detail as $detail) {
            $pdi_check_list->column_name = $detail->col_name;
            $pdi_check_list->value = $detail->val;
            
            if(!$pdi_check_list->update()){
                $arr = array(
                    "message" => "error"
                );
                echo json_encode($arr);
                die();
            }
        }

        if($data->pdi_disabled==0 && $data->pdi_done==1){
            $sales->oc_no = $data->oc_no;
            $sales->column_name = "pdi_done";

            if($sales->updateDone()){

                $sales->status = "PDI Check List";
                $sales->processing = "Ready to Deliver";
                
                if(!$sales->updateStatus()){
                    $arr = array(
                        "message" => "Status Update Error"
                    );
                    echo json_encode($arr);
                    die();
                }
            }else{
                $arr = array(
                    "message" => "error"
                );
                echo json_encode($arr);
                die();
            }
        }
        $arr = array(
            "message" => "updated"
        );
    }else{
        $arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($arr);
?>

