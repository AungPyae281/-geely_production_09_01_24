<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8"); 
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../config/database.php';
	include_once '../objects/township.php';

	$database = new Database();
	$db = $database->getConnection();
	
	$Township = new Township($db);
	$data = json_decode(file_get_contents("php://input"));

	$stmt = $Township->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["data"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				$state_division,
				$city,
				$township
			); 
			array_push($arr["data"], $detail);
		} 
	} 
	echo json_encode($arr);
?>