<?php
    session_start();
    date_default_timezone_set('Asia/Rangoon');
    
    if(!isset($_SESSION['user'])){
		header("location:http://premierauto.pal.com.mm/geely/login.html");
    }else{
        $now = time(); // checking the time now when home page starts
        if($now > $_SESSION['expire'])
        {
            session_destroy();
            header("location:http://premierauto.pal.com.mm/geely/login.html");
        }
    }
?>