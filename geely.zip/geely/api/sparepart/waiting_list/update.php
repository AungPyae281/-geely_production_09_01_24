<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sparepart_waiting_list_detail.php';

	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$sparepart_waiting_list_detail = new SparepartWaitingListDetail($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$sparepart_waiting_list_detail->waiting_list_id = $data->id;

		if($sparepart_waiting_list_detail->delete()){
			foreach ($data->spareparts_lists as $splist) {
				$sparepart_waiting_list_detail->sparepart_code = $splist->sparepart_code;
				$sparepart_waiting_list_detail->sparepart_name = $splist->sparepart_name;
				$sparepart_waiting_list_detail->quantity = $splist->quantity;

				if(!$sparepart_waiting_list_detail->create()){
					$msg_arr = array(
						"message" => "errorCreateDetail"
					);
					echo json_encode($msg_arr);
					die();
				}
			}
			$msg_arr = array(
				"message" => "updated"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}	
	echo json_encode($msg_arr);
?>