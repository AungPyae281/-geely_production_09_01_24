<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_waiting_list.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $sparepart_waiting_list = new SparepartWaitingList($db);

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['service_center']!=""){

        $sparepart_waiting_list->service_center = $_SESSION['service_center'];

        $stmt = $sparepart_waiting_list->getAllSparepartWaitingList();
        $num = $stmt->rowCount();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    $wl_id,
                    $name,
                    $phone_no,
                    $plate_no, 
                    $id
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>