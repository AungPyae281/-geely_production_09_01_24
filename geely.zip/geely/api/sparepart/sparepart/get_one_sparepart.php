<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");

	include_once '../../config/database.php';
	include_once '../../objects/sparepart.php';
	 
	$database = new Database();
	$db = $database->getConnection();

	$sparepart = new Sparepart($db);
	$data = json_decode(file_get_contents("php://input"));

	$sparepart->code = $data->code;
	$sparepart->getOneSparepart();

	$photo = array();

	$dir = "../../../upload/server/php/files/sparepart/" . $data->code ;

	if(file_exists($dir)){
		$dh  = opendir($dir);
		while (false !== ($filename = readdir($dh))) {
			$files[] = $filename;
		}
		rsort($files);
		foreach($files as $file) {
			if ($file != "." && $file != ".." && $file != "design" && $file != "thumbnail") {
				$filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file);
				array_push($photo, $file);
			}
		}
	}

	$arr = array(
	    "id" => (int)$sparepart->id,
		"group_name" => $sparepart->group_name,
		"sub_group_name" => $sparepart->sub_group_name,
		"code" => $sparepart->code,
		"name" => $sparepart->name,
		"category" => $sparepart->category,
		"origin" => $sparepart->origin,
		"unit" => $sparepart->unit,
		"sales_price" => number_format($sparepart->sales_price),
		"dealer_price" => number_format($sparepart->dealer_price),
		"description" => $sparepart->description,
		"photos" => $photo
	    );
	    echo json_encode($arr);
?>