<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_stock_transfer.php';
    include_once '../../objects/sparepart_stock_balance.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start(); 

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_stock_transfer = new SparepartStockTransfer($db);
    $sparepart_stock_balance = new SparepartStockBalance($db);
    $data = json_decode(file_get_contents("php://input"));
    
    if($_SESSION['user']!=""){
        
        $sparepart_stock_transfer->date = $data->date;
        $sparepart_stock_transfer->transfer_no = $sparepart_stock_transfer->generateTransferNo(explode("-", $data->date)[0] . explode("-", $data->date)[1]);
        $sparepart_stock_transfer->store_name_from = $data->store_name_from; 
        $sparepart_stock_transfer->store_name_to = $data->store_name_to;

        $sparepart_stock_transfer->stock_transfer_by = $data->stock_transfer_by;
        $sparepart_stock_transfer->remark = $data->remark;
        $sparepart_stock_transfer->entry_by = $_SESSION['user'];
        $sparepart_stock_transfer->entry_date_time = date("Y-m-d H:i:s");

        $sparepart_stock_balance->store_name = $data->store_name_from;  

        $out_of_stock_items = "";

        //Check Item Out of Stock
        foreach ($data->stock_details as $detail) { 

            $sparepart_stock_balance->sparepart_code = $detail->sparepart_code;

            if($sparepart_stock_balance->checkSparepartForStockOut()){
                if((int)$sparepart_stock_balance->bal_qty<=0 || (int)$sparepart_stock_balance->bal_qty<(int)$detail->quantity){
                    $out_of_stock_items .= (($out_of_stock_items=="")?'':'<br>') . '<b> - ' . $detail->sparepart_name . '</b>';
                }
            }else{
                $out_of_stock_items .= (($out_of_stock_items=="")?'':'<br>') . '<b> - ' . $detail->sparepart_name . '</b>';
            }
        }
        //Check Item Out of Stock

        if($out_of_stock_items==""){
            foreach ($data->stock_details as $detail) { 

                $sparepart_stock_transfer->sparepart_code = $detail->sparepart_code;
                $sparepart_stock_transfer->sparepart_name = $detail->sparepart_name;
                $sparepart_stock_transfer->quantity = $detail->quantity;

                $sparepart_stock_balance->sparepart_code = $detail->sparepart_code;
                $sparepart_stock_balance->reason = "Transfer";
                $sparepart_stock_balance->quantity = $detail->quantity;

                if($sparepart_stock_transfer->create()){
                    if(!$sparepart_stock_balance->updateFromStockOut()){
                        $msg_arr = array(
                            "message" => "errorStockBalanceUpdate"
                        );
                        echo json_encode($msg_arr);
                        die();
                    }  
                }else{
                    $msg_arr = array(
                        "message" => "errorStockTransferCreate"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
            }
            $msg_arr = array(
                "message" => "created"
            );
        }else{
            $msg_arr = array(
                "message" => "out of stock",
                "out_of_stock_items" => $out_of_stock_items
            );
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>