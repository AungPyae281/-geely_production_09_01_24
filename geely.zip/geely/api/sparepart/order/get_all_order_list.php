<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_order.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_order = new SparepartOrder($db);   

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['service_center']!=""){

        $sparepart_order->service_center = $_SESSION['service_center'];

        $stmt = $sparepart_order->getAllOrderList();
        $num = $stmt->rowCount();

        $i = 0;

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail=array(
                    ++$i,
                    $gic_code,
                    $order_date,
                    $order_by,
                    $remark,
                    $total_items,
                    $id,
                    $service_center,
                    $store_name
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>