<?php
class ServiceItem{ 
	private $conn;
	private $table_name = "service_item";
 
	public $id;
	public $code;
	public $name;
	public $waiting_time;
	public $price;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `name` = :name LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->name=htmlspecialchars(strip_tags($this->name));
		$stmt->bindParam(":name", $this->name);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function generateCode(){
		$query = "SELECT RIGHT(code, 4) AS code FROM `" . $this->table_name . "` ORDER BY code DESC LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return sprintf("%04d", (($row['code']) + 1));
		}else{
			return "0001";
		}
	}	 

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `code`=:code, name=:name, `waiting_time`=:waiting_time, price=:price"; 
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":waiting_time", $this->waiting_time);
		$stmt->bindParam(":price", $this->price);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET name=:name, `waiting_time`=:waiting_time, price=:price WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":waiting_time", $this->waiting_time);
		$stmt->bindParam(":price", $this->price);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY code, name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function getAllServiceItem(){	
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY code, name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}
}
?>