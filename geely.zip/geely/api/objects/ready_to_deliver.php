<?php
class ReadyToDeliver{
    private $conn;
    private $table_name = "ready_to_deliver";
 
	public $id;
	public $oc_no;

	public $ai_sidestep; 
	public $ai_floor_mat; 
	public $ai_power_tail_gate;
	public $ai_other;

	public $wfi_60;
	public $wfi_80;
	public $wfi_other;

    public $detailing_complete;
    public $detailing_general;

    public $gift;

    public function __construct($db){
        $this->conn = $db;
    }

    function getOneRow(){
		$query = "SELECT * FROM `" . $this->table_name . "` WHERE oc_no=:oc_no";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->ai_sidestep = $row['ai_sidestep'];
			$this->ai_floor_mat = $row['ai_floor_mat'];
			$this->ai_power_tail_gate = $row['ai_power_tail_gate'];
			$this->ai_other = $row['ai_other'];

			$this->wfi_60 = $row['wfi_60'];
			$this->wfi_80 = $row['wfi_80'];
			$this->wfi_other = $row['wfi_other'];
			
			$this->detailing_complete = $row['detailing_complete'];
			$this->detailing_general = $row['detailing_general'];

			$this->gift = $row['gift'];
		}
	}

    function exist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE oc_no=:oc_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

    function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET oc_no=:oc_no
		, ai_sidestep=:ai_sidestep 
		, ai_floor_mat=:ai_floor_mat 
		, ai_power_tail_gate=:ai_power_tail_gate
		, ai_other=:ai_other

		, wfi_60=:wfi_60
		, wfi_80=:wfi_80
		, wfi_other=:wfi_other

		, detailing_complete=:detailing_complete
		, detailing_general=:detailing_general

		, gift=:gift";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":oc_no", $this->oc_no);

		$stmt->bindParam(":ai_sidestep", $this->ai_sidestep);
 		$stmt->bindParam(":ai_floor_mat", $this->ai_floor_mat);
		$stmt->bindParam(":ai_power_tail_gate", $this->ai_power_tail_gate);
		$stmt->bindParam(":ai_other", $this->ai_other);

		$stmt->bindParam(":wfi_60", $this->wfi_60);
		$stmt->bindParam(":wfi_80", $this->wfi_80);
		$stmt->bindParam(":wfi_other", $this->wfi_other);

		$stmt->bindParam(":detailing_complete", $this->detailing_complete);
		$stmt->bindParam(":detailing_general", $this->detailing_general);

		$stmt->bindParam(":gift", $this->gift);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function update(){
		$query = "UPDATE `" . $this->table_name . "` SET
		, ai_sidestep=:ai_sidestep 
		, ai_floor_mat=:ai_floor_mat 
		, ai_power_tail_gate=:ai_power_tail_gate
		, ai_other=:ai_other

		, wfi_60=:wfi_60
		, wfi_80=:wfi_80
		, wfi_other=:wfi_other

		, detailing_complete=:detailing_complete
		, detailing_general=:detailing_general

		, gift=:gift WHERE oc_no=:oc_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":oc_no", $this->oc_no);
		
		$stmt->bindParam(":ai_sidestep", $this->ai_sidestep);
 		$stmt->bindParam(":ai_floor_mat", $this->ai_floor_mat);
		$stmt->bindParam(":ai_power_tail_gate", $this->ai_power_tail_gate);
		$stmt->bindParam(":ai_other", $this->ai_other);

		$stmt->bindParam(":wfi_60", $this->wfi_60);
		$stmt->bindParam(":wfi_80", $this->wfi_80);
		$stmt->bindParam(":wfi_other", $this->wfi_other);

		$stmt->bindParam(":detailing_complete", $this->detailing_complete);
		$stmt->bindParam(":detailing_general", $this->detailing_general);
		
		$stmt->bindParam(":gift", $this->gift);

		if($stmt->execute()){
			return true;
		}
		return false;
    } 
}
?>