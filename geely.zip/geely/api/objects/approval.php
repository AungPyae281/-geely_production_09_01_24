<?php
class Approval{
	private $conn;
	private $table_name = "approval";

	public $id;
	public $role;
	public $staff_id;
	public $main_id;
	public $order_no;
	public $process;
	public $approve;
	public $approve_date_time; 

	public function __construct($db){
		$this->conn = $db;
	} 

	function create(){
		$query = "INSERT INTO approval (`role`, staff_id, main_id, order_no, `process`) SELECT staff.position, aa.approval_staff_id, :main_id, aa.order_no, aa.`process` FROM approval_assign AS aa LEFT JOIN staff ON aa.approval_staff_id=staff.id WHERE aa.`process`=:process AND aa.staff_id=:staff_id";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->bindParam(":process", $this->process); 

		if($stmt->execute()){
			return true;
		}
		return false;
    }  

    function getApprovalList(){
    	$query = "SELECT approval.role, approval.staff_id, approval.main_id, approval.order_no, approval.approve, approval.`process`, IFNULL(reject.reject_date_time, '') AS reject_date_time, if(approve=1, 'Approve', if(reject_date_time<>'', 'Reject', 'Pending')) AS `status` FROM approval LEFT JOIN (SELECT * FROM reject WHERE main_id=:main_id AND `process`=:process AND `fixed`=0) AS reject ON approval.role=reject.role AND approval.main_id=reject.main_id AND approval.order_no=reject.order_no AND approval.`process`=reject.`process` WHERE approval.main_id=:main_id AND approval.`process`=:process ORDER BY order_no, approval.role";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":main_id", $this->main_id);
		
		$stmt->execute();
		return $stmt;
	}

	function getOneApprovalForOrder(){
		$query = "SELECT approval.order_no, approval.approve, aa.`condition`, aa.permission_edit, IFNULL(apv_count, 0) AS apv_count
FROM approval
LEFT JOIN approval_assign AS aa ON approval.`process`=aa.`process` AND approval.staff_id=aa.approval_staff_id AND approval.order_no=aa.order_no
LEFT JOIN (SELECT staff_id AS sid, order_no, COUNT(order_no) AS apv_count FROM approval WHERE approve=1 AND main_id=:main_id AND `process`=:process GROUP BY order_no) AS apv ON approval.order_no=apv.order_no
WHERE aa.staff_id=:se_id AND approval.staff_id=:approval_staff_id AND approval.main_id=:main_id AND approval.`process`=:process AND
approval.order_no=(SELECT MIN(order_no) AS order_no
FROM approval
WHERE main_id=:main_id AND `process`=:process AND approve=0
ORDER BY order_no
LIMIT 0, 1) LIMIT 0, 1";

		$stmt = $this->conn->prepare( $query );

		$stmt->bindParam(":se_id", $this->se_id);
		$stmt->bindParam(":approval_staff_id", $this->approval_staff_id);
		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":main_id", $this->main_id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->order_no = (int)$row['order_no'];
			$this->approve = (int)$row['approve'];
			$this->condition = $row['condition'];
			$this->permission_edit = (int)$row['permission_edit'];
			$this->apv_count = (int)$row['apv_count'];
		}else{
			$this->order_no = 0;
			$this->approve = 0;
			$this->condition = "";
			$this->permission_edit = 0;
			$this->apv_count = 0;
		}
	}

	function updateApproval(){
		$query = "UPDATE `" . $this->table_name . "` SET approve=1, approve_date_time=:approve_date_time WHERE staff_id=:staff_id AND order_no=:order_no AND main_id=:main_id AND `process`=:process; UPDATE reject SET fixed=1 WHERE main_id=:main_id AND `process`=:process";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":approve_date_time", $this->approve_date_time);
		$stmt->bindParam(":role", $this->role);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":order_no", $this->order_no);
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->bindParam(":process", $this->process);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function checkLastApproval(){
		$query = "SELECT (IFNULL(total_approval, 0) - IFNULL(approve_count, 0)) AS approve_left FROM `order` LEFT JOIN (SELECT staff_id, SUM(apv_count) AS total_approval
FROM ((
SELECT staff_id, COUNT(order_no) AS apv_count
FROM approval_assign
WHERE `process`=:process AND `condition`='AND' GROUP BY staff_id) UNION ALL (
SELECT staff_id, COUNT(distinct order_no) AS apv_count
FROM approval_assign
WHERE `process`=:process AND `condition`='OR'
GROUP BY staff_id)) AS apv GROUP BY staff_id) AS apv_assign ON `order`.staff_id=apv_assign.staff_id
LEFT JOIN (SELECT main_id, COUNT(*) AS approve_count
FROM approval
WHERE `process`=:process AND approve=1
GROUP BY main_id) AS apv ON `order`.oc_no=apv.main_id
WHERE `order`.oc_no=:main_id";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->bindParam(":process", $this->process);
		$stmt->execute();

		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		return (int)$row['approve_left'];
	}

	function getMax2Approver(){
    	$query = "SELECT * FROM (SELECT approval.role AS `position`, order_no, staff.signature
FROM approval
LEFT JOIN staff ON approval.staff_id=staff.id
WHERE main_id=:main_id AND approve=1
GROUP BY order_no
ORDER BY order_no DESC
LIMIT 0, 2) AS apv ORDER BY order_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->execute();
		return $stmt;
	}

	// function getOrderNo(){
	// 	$query = "SELECT order_no FROM " . $this->table_name . " WHERE role=:role AND staff_id=:staff_id AND main_id=:main_id AND `process`=:process ORDER BY id LIMIT 0, 1";

	// 	$stmt = $this->conn->prepare( $query );
	// 	$stmt->bindParam(":role", $this->role);
	// 	$stmt->bindParam(":staff_id", $this->staff_id);
	// 	$stmt->bindParam(":main_id", $this->main_id);
	// 	$stmt->bindParam(":process", $this->process);
	// 	$stmt->execute();

	// 	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 	return (int)$row['order_no'];
	// } 

    // function getApprovalListForNoti(){
	// 	if($this->status=="Approve"){
	// 		$query = "SELECT role, staff_id, main_id, order_no, `process` FROM approval WHERE order_no=(SELECT MIN(order_no) AS order_no FROM approval WHERE main_id=:main_id AND `process`=:process AND approve=0 ORDER BY order_no LIMIT 0, 1) AND approve=0 AND order_no<>" . $this->order_no;
	// 	}else if($this->status=="Reject"){
	// 		$query = "SELECT approval.role, approval.staff_id, approval.main_id, approval.order_no, approval.`process` FROM approval LEFT JOIN (SELECT main_id, `process`, (order_no - 1) AS order_no FROM reject WHERE main_id=:main_id AND `process`=:process AND `fixed`=0 AND order_no>1 LIMIT 0, 1) AS reject ON approval.main_id=reject.main_id AND approval.`process`=reject.`process` AND approval.order_no=reject.order_no WHERE reject.order_no IS NOT NULL";
	// 	}else{//Re-Approve
	// 		$query = "SELECT role, staff_id, main_id, order_no, `process` FROM approval WHERE order_no=(SELECT MIN(order_no) AS order_no FROM approval WHERE main_id=:main_id AND `process`=:process AND approve=0 ORDER BY order_no LIMIT 0, 1) AND approve=0";
	// 	}

	// 	$stmt = $this->conn->prepare($query);
	// 	$stmt->bindParam(":main_id", $this->main_id);
	// 	$stmt->bindParam(":process", $this->process);
	// 	$stmt->execute();
	// 	return $stmt;
	// } 
}
?>