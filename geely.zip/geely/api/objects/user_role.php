<?php
class UserRole{
	    // database connection and table name
	private $conn;
	private $table_name = "user_role";

	// object properties

	public $id;
	public $dashboard;
	public $role_name;
	public $process;
	public $create;
	public $read;
	public $update;
	public $delete;
	public $export;
	public $print;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getProcess(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE role_name=:role_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":role_name", $this->role_name);
		$stmt->execute();
		return $stmt;
	} 

	function getRoles(){
		$query = "SELECT user_role.*, IFNULL(username, '') AS username FROM " . $this->table_name . " LEFT JOIN `user` ON user_role.role_name=`user`.userrole GROUP BY user_role.dashboard, user_role.role_name ORDER BY user_role.dashboard, user_role.role_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE role_name=:role_name";
		$stmt = $this->conn->prepare( $query );
		$this->role_name = htmlspecialchars(strip_tags($this->role_name));
		$stmt->bindParam(":role_name", $this->role_name);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET dashboard=:dashboard, role_name=:role_name, `process`=:process, `create`=:cre, `read`=:read, `update`=:upd, `delete`=:del, `export`=:export, `print`=:print";
		$stmt = $this->conn->prepare( $query );

		$stmt->bindParam(":dashboard", $this->dashboard);
		$stmt->bindParam(":role_name", $this->role_name);
		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":cre", $this->create);
		$stmt->bindParam(":read", $this->read);
		$stmt->bindParam(":upd", $this->update);
		$stmt->bindParam(":del", $this->delete);
		$stmt->bindParam(":export", $this->export);
		$stmt->bindParam(":print", $this->print);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE role_name=:role_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":role_name", $this->role_name);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getRolesByDashboard(){
		$query = "SELECT id, dashboard, role_name FROM " . $this->table_name . " WHERE dashboard=:dashboard GROUP BY role_name ORDER BY role_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":dashboard", $this->dashboard);
		$stmt->execute();
		return $stmt;
	}
}
?>