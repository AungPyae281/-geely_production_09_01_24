<?php
class Sparepart{ 
	private $conn;
	private $table_name = "sparepart"; 

	public $id; 
	public $group_name; 
	public $sub_group_name;
	public $code;
	public $name;
	public $category;
	public $origin;
	public $unit;
	public $sales_price;
	public $dealer_price;
	public $description;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE code = :code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->code=htmlspecialchars(strip_tags($this->code));	 
		$stmt->bindParam(":code", $this->code);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET group_name=:group_name, sub_group_name=:sub_group_name, code=:code, name=:name, `category`=:category, `origin`=:origin, `unit`=:unit, sales_price=:sales_price, dealer_price=:dealer_price, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":group_name", $this->group_name);
		$stmt->bindParam(":sub_group_name", $this->sub_group_name);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":category", $this->category);
		$stmt->bindParam(":origin", $this->origin);
		$stmt->bindParam(":unit", $this->unit);
		$stmt->bindParam(":sales_price", $this->sales_price);
		$stmt->bindParam(":dealer_price", $this->dealer_price);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET `category`=:category, `origin`=:origin, `unit`=:unit, sales_price=:sales_price, dealer_price=:dealer_price, description=:description WHERE code=:code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":category", $this->category);
		$stmt->bindParam(":origin", $this->origin);
		$stmt->bindParam(":unit", $this->unit);
		$stmt->bindParam(":sales_price", $this->sales_price);
		$stmt->bindParam(":dealer_price", $this->dealer_price);
		$stmt->bindParam(":description", $this->description);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getOneSparepart(){	
		$query = "SELECT * FROM " . $this->table_name . " WHERE code=:code";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":code", $this->code);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->group_name = $row['group_name'];
			$this->sub_group_name = $row['sub_group_name'];
			$this->code = $row['code'];
			$this->name = $row['name'];
			$this->category = $row['category'];
			$this->origin = $row['origin'];
			$this->unit = $row['unit'];
			$this->sales_price = $row['sales_price'];
			$this->dealer_price = $row['dealer_price'];
			$this->description = $row['description'];
		}
	}

	function autocomplete(){
		$condition = "";
		
		if($this->code){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (code LIKE  :code '%' or code LIKE '%' :code '%' or code Like '%' :code )";
		}

		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (`name` LIKE  :name '%' or `name` LIKE '%' :name '%' or `name` Like '%' :name )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY group_name, sub_group_name, code, name";
		$stmt = $this->conn->prepare($query);
		if($this->code) $stmt->bindParam(":code", $this->code);
		if($this->name) $stmt->bindParam(":name", $this->name);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";

		if($this->group_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " group_name=:group_name ";
		}

		if($this->sub_group_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " sub_group_name=:sub_group_name ";
		}

		if($this->code){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " code=:code ";
		}

		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " name=:name ";
		}

		if($this->category){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " category=:category ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY group_name, sub_group_name, code, name"; 

		$stmt = $this->conn->prepare($query);

		if($this->group_name) $stmt->bindParam(":group_name", $this->group_name);
		if($this->sub_group_name) $stmt->bindParam(":sub_group_name", $this->sub_group_name);
		if($this->code) $stmt->bindParam(":code", $this->code);
		if($this->name) $stmt->bindParam(":name", $this->name);
		if($this->category) $stmt->bindParam(":category", $this->category);

		$stmt->execute();
		return $stmt;
	} 

	function getAllSpareparts(){//HHYS
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY group_name, sub_group_name, code, name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllSparepartsByServiceCenter(){//HHYS
		$query = "SELECT sparepart.*, IFNULL(avail_qty, 0) AS avail_qty FROM " . $this->table_name . "
		LEFT JOIN (SELECT sparepart_code, (SUM(total_stock_in) + SUM(total_receive) - SUM(total_issue_note) - SUM(total_lock) - SUM(total_damage) - SUM(total_lost) - SUM(total_return) - SUM(total_transfer)) AS avail_qty FROM sparepart_stock_balance AS ssb
		LEFT JOIN service_center_store AS scs ON ssb.store_name=scs.store_name WHERE scs.service_center=:service_center GROUP BY sparepart_code) AS sb ON sparepart.code=sb.sparepart_code WHERE IFNULL(avail_qty, 0)>0 ORDER BY sparepart.group_name, sparepart.sub_group_name, sparepart.code";
		$stmt = $this->conn->prepare( $query );
		$this->service_center=htmlspecialchars(strip_tags($this->service_center));
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function getAllSparepartsWithAvailStock(){//HHYS
		$query = "SELECT sparepart.*, IFNULL(avail_qty, 0) AS avail_qty FROM " . $this->table_name . "
		LEFT JOIN (SELECT sparepart_code, (SUM(total_stock_in) + SUM(total_receive) - SUM(total_issue_note) - SUM(total_lock) - SUM(total_damage) - SUM(total_lost) - SUM(total_return) - SUM(total_transfer)) AS avail_qty FROM sparepart_stock_balance AS ssb
		LEFT JOIN service_center_store AS scs ON ssb.store_name=scs.store_name WHERE scs.service_center=:service_center GROUP BY sparepart_code) AS sb ON sparepart.code=sb.sparepart_code ORDER BY sparepart.group_name, sparepart.sub_group_name, sparepart.code";
		$stmt = $this->conn->prepare( $query );
		$this->service_center=htmlspecialchars(strip_tags($this->service_center));
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}  
}
?>