<?php
class SalesCenter{
	private $conn;
	private $table_name = "sales_center";

	public $id;
	public $name;
	public $is_delete;

	public function __construct($db){
		$this->conn = $db;
	}	

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE is_delete=0 ORDER BY name";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
}
?>