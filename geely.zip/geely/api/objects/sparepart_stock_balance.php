<?php
class SparepartStockBalance{ 
	private $conn;
	private $table_name = "sparepart_stock_balance"; 

	public $id;
	public $store_name; 
	public $sparepart_code;
	public $sparepart_name;
	public $total_stock_in;
	public $total_sales;
	public $total_lock;
	public $total_damage;
	public $total_lost;
	public $total_return;
	public $total_transfer;
	public $total_receive;

	public function __construct($db){
		$this->conn = $db;
	}

	function checkSparepartForService(){
		$query = "SELECT (SUM(total_stock_in) + SUM(total_receive) - SUM(total_issue_note) - SUM(total_lock) - SUM(total_damage) - SUM(total_lost) - SUM(total_return) - SUM(total_transfer)) AS bal_qty FROM " . $this->table_name . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":store_name", $this->store_name);
        $stmt->bindParam(":sparepart_code", $this->sparepart_code);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			if((int)$row['bal_qty']>=$this->quantity){
				return true;
			}else{
				return false;
			}
		}
		return false;
	}

	function updateFromServiceIssueNote(){
		$statement = "";
		if($this->sign=="+"){
			$statement = " total_lock=total_lock + :quantity ";
		}else{
			$statement = " total_lock=total_lock - :quantity ";
		}
		$query = "UPDATE " . $this->table_name . " SET " . $statement . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function checkSparepartForStockOut(){
		$query = "SELECT (total_stock_in + total_receive - total_issue_note - total_lock - total_damage - total_lost - total_return - total_transfer) AS bal_qty FROM " . $this->table_name . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":store_name", $this->store_name); 
        $stmt->bindParam(":sparepart_code", $this->sparepart_code);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->bal_qty = (int)$row['bal_qty'];
			return true;
		}
		return false;
	}	

	function updateFromStockOut(){
		$statement = "";
		if($this->reason=="Damage"){
			$statement = " total_damage = total_damage + :quantity ";
		}else if($this->reason=="Lost"){
			$statement = " total_lost = total_lost + :quantity ";
		}else if($this->reason=="Issue Note"){
			$statement = " total_issue_note = total_issue_note + :quantity ";
		}else if($this->reason=="Transfer"){
			$statement = " total_transfer = total_transfer + :quantity ";
		}else if($this->reason=="Return"){
			$statement = " total_return = total_return + :quantity ";
		}
		$query = "UPDATE " . $this->table_name . " SET " . $statement . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->store_name=htmlspecialchars(strip_tags($this->store_name));
		$this->sparepart_code=htmlspecialchars(strip_tags($this->sparepart_code));
	 
		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function updateFromReceiving(){
		$query = "UPDATE " . $this->table_name . " SET total_stock_in=total_stock_in + :total_stock_in, total_lock=total_lock + :total_lock WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":total_stock_in", $this->total_stock_in);
		$stmt->bindParam(":total_lock", $this->total_lock);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET store_name=:store_name, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, total_stock_in=:total_stock_in, total_lock=:total_lock";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":total_stock_in", $this->total_stock_in);
		$stmt->bindParam(":total_lock", $this->total_lock);
		 
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateFromStockOutDelete(){
		$statement = "";
		if($this->reason=="Damage"){
			$statement = " total_damage = total_damage - :quantity ";
		}else if($this->reason=="Lost"){
			$statement = " total_lost = total_lost - :quantity ";
		}else if($this->reason=="Issue Note"){
			$statement = " total_issue_note = total_issue_note - :quantity ";
		}
		$query = "UPDATE " . $this->table_name . " SET " . $statement . " WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getAllSparepartsByStore(){
		$query = "SELECT `group_name`, `sub_group_name`, ssb.sparepart_code, ssb.sparepart_name, category, (total_stock_in + total_receive - total_issue_note - total_lock - total_damage - total_lost - total_return - total_transfer) AS bal_qty FROM sparepart_stock_balance AS ssb LEFT JOIN sparepart ON ssb.sparepart_code=sparepart.code WHERE store_name=:store_name AND (total_stock_in + total_receive - total_issue_note - total_lock - total_damage - total_lost - total_return - total_transfer)>0 ORDER BY group_name, sub_group_name, ssb.sparepart_code, ssb.sparepart_name";
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":store_name", $this->store_name); 	 
		$stmt->execute();
		return $stmt;
	} 

	function updateFromStockReceive(){
		$query = "UPDATE " . $this->table_name . " SET total_receive=total_receive + :quantity WHERE store_name=:store_name AND sparepart_code=:sparepart_code";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

	function createFromStockReceive(){
		$query = "INSERT INTO " . $this->table_name . " SET store_name=:store_name, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, total_receive=:quantity";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);
		 
		if($stmt->execute()){
			return true;
		}
		return false;
	}   

	// function search(){
	// 	$condition = "";
		
	// 	if($this->store_name){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " store_name=:store_name ";
	// 	}

	// 	if($this->sparepart_code){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " sparepart_code=:sparepart_code ";
	// 	}

	// 	if($this->sparepart_name){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " sparepart_name=:sparepart_name";
	// 	}

	// 	if($condition!=""){
	// 		$condition = " WHERE " . $condition;
	// 	}

	// 	$query = "SELECT store_name, sparepart_code, sparepart_name, SUM(total_stock_in) AS in_qty, SUM(total_damage + total_lost) AS out_qty, SUM(total_issue_note) AS issue_note_qty, SUM(total_receive) AS receive_qty, SUM(total_transfer) AS transfer_qty, SUM(total_lock) AS lock_qty, SUM(total_return) AS return_qty FROM " . $this->table_name . $condition . " GROUP BY store_name, sparepart_code ORDER BY store_name, sparepart_code";
	// 	$stmt = $this->conn->prepare($query);
	// 	if($this->store_name) $stmt->bindParam(":store_name", $this->store_name);
	// 	if($this->sparepart_code) $stmt->bindParam(":sparepart_code", $this->sparepart_code);
	// 	if($this->sparepart_name) $stmt->bindParam(":sparepart_name", $this->sparepart_name);
	// 	$stmt->execute();
	// 	return $stmt;
	// }
}
?>