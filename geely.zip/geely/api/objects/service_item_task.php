<?php
class ServiceItemTask{ 
	private $conn;
	private $table_name = "service_item_task"; 

	public $id;
	public $service_item_id;
	public $description;
	public $tips;
	public $requirements;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE service_item_id = :service_item_id AND description = :description AND tips = :tips AND requirements = :requirements LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	
	 
		$stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":tips", $this->tips);
		$stmt->bindParam(":requirements", $this->requirements);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_item_id=:service_item_id, description=:description, tips=:tips, requirements=:requirements, entry_by=:entry_by, entry_date_time=:entry_date_time ";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":tips", $this->tips);
		$stmt->bindParam(":requirements", $this->requirements);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 
	 
	function update(){
		$query = "UPDATE " . $this->table_name . " SET service_item_id=:service_item_id, description=:description, tips=:tips, requirements=:requirements where id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":tips", $this->tips);
		$stmt->bindParam(":requirements", $this->requirements);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getAllRows(){
		$condition = "";
		if($this->service_item_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " service_item_id =:service_item_id ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT service_item_task.*, `name` as service_item_name FROM " . $this->table_name . " LEFT JOIN service_item ON service_item_task.service_item_id=service_item.id " . $condition . " ORDER BY service_item_id, service_item_task.entry_date_time";
		$stmt = $this->conn->prepare( $query );
		if($this->service_item_id) $stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->execute();
		return $stmt;
	}
}
?>