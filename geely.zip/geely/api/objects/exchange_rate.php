<?php
class ExchangeRate{
	private $conn;
	private $table_name = "exchange_rate";

	public $id;
	public $date;
	public $currency;
	public $rate;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	} 

    function create(){
    	$query = "INSERT INTO " . $this->table_name . " SET `date`=:date, `currency`=:currency, `rate`=:rate, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":rate", $this->rate);	
		$stmt->bindParam(":entry_by", $this->entry_by);	
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function isExist(){
    	$query = "SELECT id FROM " . $this->table_name . " WHERE `date`=:date AND `currency`=:currency AND `rate`=:rate";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":rate", $this->rate);	
		
		$stmt->execute();

		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getAllRows(){
    	$query = "SELECT * FROM " . $this->table_name . " ORDER BY `date` DESC, `currency`, `entry_date_time`";
		$stmt = $this->conn->prepare($query);		
		$stmt->execute();
		return $stmt;
	}
}
?>