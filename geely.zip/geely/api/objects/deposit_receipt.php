<?php
class DepositReceipt{
    private $conn;
    private $table_name = "deposit_receipt";
 
	public $id;
	public $oc_no;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $r_date;
	public $r_payment_type;
	public $receipt_no;
	public $receipt_img;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    } 

    function create(){
		$statement = "";
		if($this->receipt_img){
			$statement = ", receipt_img=:receipt_img";
		}
		$query = "UPDATE `sales` SET `payment_due_date_time`=:payment_due_date_time WHERE oc_no=:oc_no; INSERT INTO `" . $this->table_name . "` SET oc_no=:oc_no, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, r_date=:r_date, r_payment_type=:r_payment_type, receipt_no=:receipt_no, entry_by=:entry_by, entry_date_time=:entry_date_time " . $statement;
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":r_date", $this->r_date);
		$stmt->bindParam(":r_payment_type", $this->r_payment_type);
		$stmt->bindParam(":receipt_no", $this->receipt_no); 
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		if($this->receipt_img) $stmt->bindParam(":receipt_img", $this->receipt_img);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function updatePaymentDueDateTime(){
		$query = "UPDATE `sales` SET `payment_due_date_time`=:payment_due_date_time WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
		$stmt->bindParam(":oc_no", $this->oc_no);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getOneRow(){	
		$query = "SELECT deposit_receipt.*, sales.deposit FROM " . $this->table_name . " RIGHT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE sales.oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->r_date = $row['r_date'];
			$this->gl_code = $row['gl_code'];
			$this->gl_code_bank_or_cash = $row['gl_code_bank_or_cash'];
			$this->r_payment_type = $row['r_payment_type'];
			$this->receipt_no = $row['receipt_no'];
			$this->receipt_img = $row['receipt_img'];
			$this->deposit = $row['deposit'];
		}
	}

	// function getOneDepositReceipt(){	
	// 	$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no";
	// 	$stmt = $this->conn->prepare($query);
			
	// 	$stmt->bindParam(":oc_no", $this->oc_no);

	// 	$stmt->execute();
	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		$this->oc_no = $row['oc_no'];
	// 		$this->r_date = $row['r_date'];
	// 		$this->r_payment_type = $row['r_payment_type'];
	// 		$this->receipt_no = $row['receipt_no'];
	// 		$this->receipt_img = $row['receipt_img'];
	// 	}
	// }
}
?>
