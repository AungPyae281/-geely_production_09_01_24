<?php
class SparepartReceiving{ 
	private $conn;
	private $table_name = "sparepart_receiving"; 

	public $id;
	public $gic_code;
	public $receive_date;
	public $store;
	public $receive_by;
	public $remark;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gic_code=:gic_code, receive_date=:receive_date, `store`=:store, `receive_by`=:receive_by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gic_code", $this->gic_code);
		$stmt->bindParam(":receive_date", $this->receive_date);
		$stmt->bindParam(":store", $this->store);
		$stmt->bindParam(":receive_by", $this->receive_by);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}
}
?>