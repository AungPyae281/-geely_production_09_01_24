		<footer class="main-footer">
			<strong> Developed By <a href="http://cluspedia.com"> Cluspedia</a>.</strong>
			<div class="float-right d-none d-sm-inline-block">
				<b>Version</b> 1.0.0
			</div>
		</footer>
	</div> 
</body>

<script src="<?=$app_url;?>plugins/jquery/jquery.min.js"></script> 
<script src="<?=$app_url;?>plugins/jquery-ui/jquery-ui.min.js"></script> 
<script src="<?=$app_url;?>plugins/bootbox/bootbox.min.js"></script> 
<script src="<?=$app_url;?>plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?=$app_url;?>plugins/bootstrap/bootstrap-toggle.min.js"></script>
<script src="<?=$app_url;?>plugins/datepicker/bootstrap-datepicker.min.js"></script>	
<script src="<?=$app_url;?>plugins/timepicker/bootstrap-timepicker.min.js"></script> 
<script src="<?=$app_url;?>plugins/datatables/jquery.dataTables.min.js"></script> 
<script src="<?=$app_url;?>plugins/toastr/toastr.min.js"></script> 
<script src="<?=$app_url;?>plugins/signaturepad/jquery.signaturepad.js"></script> 

<script src="<?=$app_url;?>dist/js/adminlte.min.js"></script>
<script src="<?=$app_url;?>dist/js/tableExport.js"></script>	 
<script src="<?=$app_url;?>dist/js/xlsx.core.min.js"></script>	

<script src="<?=$app_url;?>plugins/toastr/sweetalert2.min.js"></script>
<script src="<?=$app_url;?>plugins/toastr/toastr.min.js"></script>
 
<script src="<?=$app_url;?>plugins/signaturepad/signature_pad.umd.min.js"></script>	

<script> 
	$(function() {
		if(window.location.pathname.indexOf(".php") != -1){
			$('.nav-sidebar li a').each(function (){
				$(this).removeClass('activee');
			});
			
			$('.nav-link-treeview').each(function (){
				if($(this).attr("href").indexOf(window.location.pathname)!=-1 && window.location.pathname.indexOf(".php") !=-1){
					$(this).attr("class", $(this).attr("class") + " activeMenu");
					$(this).find("i[data-custom='sub']").removeClass('far fa-folder').addClass('far fa-folder-open');
					if($(this).parent().parent().parent().hasClass("has-treeview")){
						$(this).parent().parent().css("display","block");
						$(this).parent().parent().parent().find("a:first").addClass("activee");
					}
				}
			});
		}	 
		showHideMenu();		 
	}); 
	
	function showHideMenu(){
		$("a[data]").each(function( index ) {
			$(this).closest("li").css("display","none");
		});
		if("<?=$_SESSION['userrole']?>"!="KEY"){
			$.ajax({
				url: APP_URL + "api/userrole/get_process.php"
			}).done(function(data) { 
				$.each(data.records, function(i, v) {   
					$("a[data]").each(function( index ) {
						var attrVal = $(this).attr("data");
						if(v.process == attrVal.split("|")[0]){
							var showTF = true;
							var pArrTF = attrVal.split("|")[1].split("");
							for(var i = 0; i < 6; i++){
								if(pArrTF[i] == "1"){
									if(i == 0 && v.create == "0") { showTF = false; break; }
									if(i == 1 && v.read == "0") { showTF = false; break; }
									if(i == 2 && v.update == "0") { showTF = false; break; }
									if(i == 3 && v.delete == "0") { showTF = false; break; }
									if(i == 4 && v.export == "0") { showTF = false; break; }
									if(i == 5 && v.print == "0") { showTF = false; break; }
								}
							}
							if(showTF){
								$(this).closest("li").css("display", "block");
							}
						}
					});
				});

				$(".has-treeview").each(function(index){
					var $this = $(this);
					var showTF = false;
					$this.find(".nav-item").each(function(e, index){
						if($(this).css("display")=="block" || $(this).css("display")=="list-item") showTF = true;
					});
					if(!showTF) $this.css("display", "none");
				});
			});
		}else{
			$("a[data-key]").each(function( index ) {
				$(this).closest("li").css("display","block");
			});	

			$(".has-treeview").each(function(index){
				var $this = $(this);
				var showTF = false;
				$this.find(".nav-item").each(function(e, index){ 
					if($(this).css("display")=="block" || $(this).css("display")=="list-item") showTF = true;
				});
				if(!showTF) $this.css("display", "none");
			});
		} 
	}

	function exportExcel(myTable){
		var table = $(myTable);
		$(table).tableExport({
			type: 'xlsx',
			fileName: "SCS" + new Date().toISOString().replace(/[\-\:\.]/g, ""),
			excel: {fileFormat: 'xlsx'}
		});
	}

	function isString(event) {
		var inputValue = event.charCode;
        if(!((inputValue > 64 && inputValue < 91) || (inputValue > 96 && inputValue < 123)||(inputValue==32) || (inputValue==0))){
            event.preventDefault();
        }
	}
</script>	
</html>
