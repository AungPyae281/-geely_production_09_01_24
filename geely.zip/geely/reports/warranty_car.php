<?php include '../header.php'; ?>
<style>
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 100%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	}

	.switch {
	  position: relative;
	  display: inline-block;
	  width: 60px;
	  height: 25px;
	  margin-top: 6px;
	}

	/* Hide default HTML checkbox */
	.switch input {
	  display:none;
	}

	/* The slider */
	.slider {
	  position: absolute;
	  cursor: pointer;
	  top: 0;
	  left: 0;
	  right: 0;
	  bottom: 0;
	  background-color: #ccc;
	  -webkit-transition: .4s;
	  transition: .4s;
	}

	.slider:before {
	  position: absolute;
	  content: "";
	  height: 22px;
	  width: 22px;
	  left: 5px;
	  bottom: 1px;
	  background-color: white;
	  -webkit-transition: .4s;
	  transition: .4s;
	}

	input:checked + .slider {
	  background-color: #dc3545;
	}

	input:focus + .slider {
	  box-shadow: 0 0 1px #dc3545;
	}

	input:checked + .slider:before {
	  -webkit-transform: translateX(26px);
	  -ms-transform: translateX(26px);
	  transform: translateX(26px);
	}

	/* Rounded sliders */
	.slider.round {
	  border-radius: 34px;
	}

	.slider.round:before {
	  border-radius: 50%;
	}

	textarea{
		height: 68px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Warranty Car - Report</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">		
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPlateNo">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Warranty</label>
											<div class="col-md-8" style="padding:7px;">
												<label class="control-label col-md-3">
													<input id="optAll" name="optWarranty" type="radio" value="" checked>
													All
												</label>
												<label class="control-label col-md-3">
													<input id="optYes" name="optWarranty" value="Yes" type="radio">
													Yes
												</label>
												<label class="control-label col-md-3">
													<input id="optNo" name="optWarranty" value="No" type="radio">
													No
												</label>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div> 	
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Warranty List <span id="total_records" style="font-weight:bold;"></span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">#</th>
								<th>Plate No.</th>
								<th>Kilometer</th>
								<th>Last Visited Date</th>
								<th>A</th>
								<th>B</th>
								<th>C</th>
								<th>D</th>
								<th>E</th>
								<th style="width: 8%"></th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>

			<center>
				<div class="modal fade modal-primary" id="myModalTerminate">
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 80%; top: 29px;">
							<div class="modal-header">
								<h4 class="modal-title" style="font-size: 20px !important;">Plate No. - <span id="txtPlateNoM"></span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" style="padding: 0px;">
								<div class="col-md-12 card-body p-0" style="min-height: 340px;">
									<table class="table table-bordered" id="myTable1">
										<thead>                  
											<tr>
												<th style="width: 6%">#</th>
												<th style="text-align: center; vertical-align: middle;">Warranty</th>
												<th style="width: 12%; text-align: center; vertical-align: middle;">Status</th>
												<th style="width: 10%; text-align: center; vertical-align: middle;">Date</th>
												<th style="width: 28%; text-align: center; vertical-align: middle;">Remark</th>
												<th style="width: 6%; text-align: center; vertical-align: middle;">Terminate</th>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</center>

		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function(){
		$("body").addClass("sidebar-collapse");	
		autocomplete(document.getElementById("txtPlateNo")); 
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	function autocomplete(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/service/warranty_car/autocomplete.php",
				type: "POST",
				data: JSON.stringify({ plate_no: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var plate_no = arr[i]['plate_no'];
				b = document.createElement("DIV");
				b.innerHTML = plate_no.replace(strRegExp, '<b>'+val+'</b>');
				b.innerHTML += "<input type='hidden' value='" + plate_no.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function search(){
		$("#loading").css("display","block");
		var plate_no = $("#txtPlateNo").val();
		var warranty_status = $("input[name='optWarranty']:checked").val();

		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/service/warranty_car/search.php",
			data: JSON.stringify({ plate_no: plate_no, warranty_status: warranty_status })
		}).done(function(data) {	
			$("#loading").css("display","none");
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			$.each(data.records, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.plate_no + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.kilometer + "</td>")
					.append("<td>" + v.last_visited_date + "</td>")
					.append("<td>" + v.warranty1 + "</td>")
					.append("<td>" + v.warranty2 + "</td>")
					.append("<td>" + v.warranty3 + "</td>")
					.append("<td>" + v.warranty4 + "</td>")
					.append("<td>" + v.warranty5 + "</td>")
					.append("<td><button class='btn btn-danger btn-sm' onclick='goToTerminate(\"" + v.plate_no + "\")'>Terminate</button></td>")
				);
			});
       });
	}

	function goToTerminate(plate_no){
		$("#myModalTerminate").modal('show');
		$("#txtPlateNoM").text(plate_no);

		$("#myTable1").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/service/warranty_car/get_warranty_by_plate_no.php",
			data: JSON.stringify({ plate_no: plate_no })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {
				var remark = "";
				var checked = "";
				var disabled = "";
				var cursor = 0;
				if(v.status=="Valid"){
					remark = "<textarea class='form-control' id='txtRemark" + (i + 1) + "' style='height: 68px;'></textarea>";
				}else{
					remark = v.remark;
					disabled = "disabled";
					cursor = 1;
				}

				if(v.status=="Terminate"){
					checked = "checked";
				}

				$("#myTable1").find("tbody")
				.append($('<tr data-plate-no="' + v.plate_no + '" data-id="' + v.id + '">')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.warranty + "</td>")
					.append("<td>" + v.status + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td style='" + ((v.status=="Valid")?'padding: 0px;':'') + "'>" + remark + "</td>")
					.append("<td><label class='switch'><input type='checkbox' onclick='gotoTerminate(\"" + v.id + "\", \"" + v.plate_no + "\", this)' " + checked + " " + disabled + "><span class='slider round' style='" + ((cursor==0)?'':'cursor: no-drop;') + "'></span></label></td>")
				);
			});
		});
	}

	function gotoTerminate(id, plate_no, obj){
		var terminate = ($(obj).prop("checked"))?1:0;
		var remark = $(obj).parent().parent().parent().find("textarea").eq(0).val();

		if(terminate==1){
			$(obj).prop("disabled", true);
			bootbox.confirm({
				message: "<h4>Are you sure that you want to terminate?</h4>",
				buttons: {
					confirm: {
						label: '<span class="glyphicon glyphicon-ok"></span> Yes',
						className: 'btn-primary'
					},
					cancel: {
						label: '<span class="glyphicon glyphicon-remove"></span> No',
						className: 'btn-danger'
					}
				},
				callback: function (result) {
					if(result){
						$.ajax({
							type: "POST",
							url: APP_URL + "api/service/warranty_car/update_terminate.php",
							data: JSON.stringify({ id: id, plate_no: plate_no, status: "Terminate", remark: remark })
						}).done(function(data) {
							if(data.message=="updated"){
								bootbox.alert("Successfully terminated.");
								goToTerminate(plate_no);
							}else if(data.message=="session expire"){
								bootbox.alert("Session Expire! Please refresh the browser and login again.");
							}else{
								bootbox.alert("Error on server side.");
							}
						});
					}else{
						$(obj).prop("disabled", false);
						$(obj).prop("checked", false);
					}
				}
			});
		}
	}
</script>
