<?php include '../header.php'; ?>
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Route - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">dashboard: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtDashboard">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">module: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtModule">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">route: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRoute">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">process: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtProcesss">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">title: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTitle">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">create: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCreate" value="0">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">read: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRead" value="0">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">update: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtUpdate" value="0">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">delete: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtDelete"  value="0">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">export: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtExport"  value="0">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">print: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPrint" value="0">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-7">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>dashboard</th>
										<th>module</th>
										<th>route</th>
										<th>process</th>
										<th>title</th>
										<th>create</th>
										<th>read</th>
										<th>update</th>
										<th>delete</th>
										<th>export</th>
										<th>print</th>
										<th>Act</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		$("body").addClass("sidebar-collapse");
		getAllRows();
	});

	function create(){
		var dashboard = $("#txtDashboard").val();
		var modules = $("#txtModule").val();
		var route = $("#txtRoute").val();
		var processs = $("#txtProcesss").val();
		var title = $("#txtTitle").val();
		var create = $("#txtCreate").val();
		var read = $("#txtRead").val();
		var update = $("#txtUpdate").val();
		var deletes = $("#txtDelete").val();
		var exportss = $("#txtExport").val();
		var print = $("#txtPrint").val();

		if(dashboard==""){
			bootbox.alert("Please choose Brand.");
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/supply_chain/route/create.php",
				type: "POST",
				data: JSON.stringify({ dashboard: dashboard, modules: modules, route: route, processs: processs, title: title, create: create, read: read, update: update, deletes: deletes, exportss: exportss, print: print  }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#txtGrade").val("");
					$("#txtEnginePower").val("");
					$("#txtRTADTax").val(0);
					bootbox.alert("Successfully Added.");
					getAllRows();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate grade.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function getAllRows(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/supply_chain/route/get_all_rows.php"
		}).done(function(data) {	
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}

			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i + 1) + "</td>")
					.append("<td>" + v.dashboard + "</td>")
					.append("<td>" + v.modules + "</td>")
					.append("<td>" + v.route + "</td>")
					.append("<td>" + v.processs + "</td>")
					.append("<td>" + v.title + "</td>")
					.append("<td>" + v.create + "</td>")
					.append("<td>" + v.read + "</td>")
					.append("<td>" + v.update + "</td>")
					.append("<td>" + v.deletes + "</td>")
					.append("<td>" + v.exportss + "</td>")
					.append("<td>" + v.print + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='del(" + v.id + ", this)' style='padding: 0px 10px;font-size: 17px; min-width: 35px'>&times;</button></td>")
				);
			});
		});
	} 

	function del(id, obj){
		bootbox.confirm({
			message: "<h4>ဤအကြောင်းအရာကို ဖျက်ရန်သေချာပါသလား?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> ဖျက်မည်',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> မဖျက်ပါ',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/supply_chain/route/delete.php",
						data: JSON.stringify({ id: id }),
					}).done(function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							getAll();
							bootbox.alert("Error on server side.");
						}else{
							bootbox.alert("Error on server side.");
						}
					});
				}
			}
		});
	}	

    function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }
</script>	
