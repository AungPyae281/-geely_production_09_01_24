<?php include '../header.php'; ?> 
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Due Date Setting</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Process</th>
										<th>Due Day</th>
										<th>Due Hour</th>
										<th style="width: 3%">Edit</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
				<center>
					<div id="myModalDueDateSetting" class="modal fade modal-primary"> 
						<div class="modal-dialog" style="max-width: 100% !important;">
							<div class="modal-content" style="width: 515px; top: 29px;">
								<div class="modal-header" style="padding-top: 7px; padding-bottom: 7px;">
									<h3 class="modal-title" style="font-size: 17px; font-weight: bold;" id="">Due Date Setting</h3>
									<button type="button" class="close" data-dismiss="modal">×</button>
								</div>
								<div class="modal-body">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-4 col-form-label" style="text-align: right;">Process: </label>
												<div class="col-md-7">
													<input type="text" class="form-control" id="txtProcess" disabled>
												</div>
												<div class="col-md-1"></div>
											</div>
											<div class="form-group row">
												<label class="col-md-4 col-form-label" style="text-align: right;">Due Day/Hour: </label>
												<div class="col-md-3">
													<input type="number" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtDay" value="0" min="0" style="text-align:right;">
												</div>
												<div class="col-md-4">
													<select class="form-control" id="cboHour">
														<option value="0"></option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
													</select>
												</div>
												<div class="col-md-1"></div>
											</div>
											<div class="form-group row">
												<div class="col-md-7"></div>
												<div class="col-md-4">
													<button type="button" class="btn btn-block btn-primary" id="btnUpdate" onclick="validateAndUpdate();">Update</button>
												</div>
												<div class="col-md-1"></div>
											</div>
										</div>
									</div> 
								</div>
							</div>
						</div>
					</div>
				</center>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var OBJ = "";
	var ID = "";

	$(function() {
		getAllRows(); 
	});

	function getAllRows(){ 
        $("#myTable").find("tbody").find("tr").remove();
        $.ajax({
            url: APP_URL + "api/admin/due_date_setting/get_all_rows.php"
        }).done(function(data) {
            if(data.records.length>1){
            	$("#total_records").text(" - " + data.records.length + " records found.");
            }else{
            	$("#total_records").text(" - " + data.records.length + " record found.");
            }
            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.process + "</td>")
                    .append("<td>" + ((v.due_day>0)?v.due_day:'') + "</td>")
                    .append("<td>" + ((v.due_hour>0)?v.due_hour:'') + "</td>")
                    .append("<td style='text-align: center;'><button type='button' class='btn btn-block btn-success btn-sm fas fa-edit' onclick='edit(\"" + v.id + "\", this)' style='padding: 0px 13px; font-size: 20px; min-width: 37px;'></button></td>")
                )
            });
        });
    } 

    function edit(id, obj){
    	OBJ = obj;
    	ID = id;
    	var day = $(obj).parent().parent().find("td").eq(2).text();
    	var hour = $(obj).parent().parent().find("td").eq(3).text();
    	$("#txtProcess").val($(obj).parent().parent().find("td").eq(1).text());
    	$("#txtDay").val((day)?day:0);
    	$("#cboHour").val((hour)?hour:0);
    	$("#myModalDueDateSetting").modal("show");
    }

    function validateAndUpdate(){
    	var due_day = parseInt($("#txtDay").val());
    	var due_hour = parseInt($("#cboHour").val());

    	if(due_day==0 && due_hour==0){
    		bootbox.alert("Please fill the boxes.");
    	}else{
    		$.ajax({
	            url: APP_URL + "api/admin/due_date_setting/update.php",
	            type: "POST",
	            data: JSON.stringify({ id: ID, due_day: due_day, due_hour: due_hour })
	        }).done(function(data) {
	        	if(data.message=="updated"){
	        		$(OBJ).parent().parent().find("td").eq(2).text((due_day>0)?due_day:"");
	        		$(OBJ).parent().parent().find("td").eq(3).text((due_hour>0)?due_hour:"");
	        		OBJ = "";
	        		ID = "";
    				$("#myModalDueDateSetting").modal("hide");
	        		bootbox.alert("Successfully updated.");
	        	}else{
	        		bootbox.alert("Error on server side.");
	        	}
	        });
    	}
    }

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(1);
	}	
</script>	
